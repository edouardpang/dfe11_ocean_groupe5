      INTEGER jpi,jpj,jpk,jpim1,jpjm1,jpt
      INTEGER jptra, ik
!
!     PARAMETER (jpi=302,jpj=52,jpk=1)
      PARAMETER (jpi=102,jpj=202,jpk=1)
!     PARAMETER (jpi=52,jpj=52,jpk=1)
      PARAMETER (jpim1=jpi-1,jpjm1=jpj-1)
      PARAMETER (jptra=1)
      PARAMETER (ik=1)
